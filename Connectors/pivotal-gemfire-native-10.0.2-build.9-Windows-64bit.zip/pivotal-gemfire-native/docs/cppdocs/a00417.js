var a00417 =
[
    [ "close", "a00417.html#a9b19ef4cf7945657df11c9378a4662f5", null ],
    [ "onError", "a00417.html#a4050fa02b1386d48a6f9877464a892bc", null ],
    [ "onEvent", "a00417.html#a5ba90775e233d64d2c20e190862f0bc9", null ]
];