var a00285 =
[
    [ "close", "a00285.html#a47f7fef7730063963b8d33ef63a520fa", null ],
    [ "getCredentials", "a00285.html#a2f89d1168170a72cf8abc2f6c2eb5ec0", null ]
];