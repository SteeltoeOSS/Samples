var a00485 =
[
    [ "getMessage", "a00485.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00485.html#a3601214e8e71ad15e04950c7315cd38a", null ],
    [ "getStackTrace", "a00485.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];