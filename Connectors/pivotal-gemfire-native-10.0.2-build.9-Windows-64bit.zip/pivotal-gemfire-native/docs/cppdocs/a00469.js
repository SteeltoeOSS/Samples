var a00469 =
[
    [ "getMessage", "a00469.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00469.html#a3a0ee55b71babdf900851391d8a5190c", null ],
    [ "getStackTrace", "a00469.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];