var a00873 =
[
    [ "registerPdxSerializer", "a00873.html#afb5a38b9f90a046905f5e8442b39a515", null ],
    [ "registerPdxType", "a00873.html#a54843eaf861f9fca21e6c912aac99155", null ],
    [ "registerType", "a00873.html#a011b069fd880744c2910b6ee5892b247", null ]
];