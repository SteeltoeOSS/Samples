var a00509 =
[
    [ "getMessage", "a00509.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00509.html#a448f7065b5e6498ac6f5ca93fa56876d", null ],
    [ "getStackTrace", "a00509.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];