var a00557 =
[
    [ "getMessage", "a00557.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00557.html#a1114ebb8dc6913474d008f3abe7f112e", null ],
    [ "getStackTrace", "a00557.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];