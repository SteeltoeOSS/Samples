var a00765 =
[
    [ "fromData", "a00765.html#a22e54f87f6f33015f0fd3540cbf04904", null ],
    [ "getObjectSizer", "a00765.html#a72905d9c266ae456ac9d444765ebb00c", null ],
    [ "toData", "a00765.html#aa579b393af4dc00ed192a6727aba847c", null ]
];