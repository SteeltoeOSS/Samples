var a00701 =
[
    [ "getMessage", "a00701.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00701.html#a97ba0a8609802e99f9042ee751ad7c57", null ],
    [ "getStackTrace", "a00701.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];