var a00489 =
[
    [ "getMessage", "a00489.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00489.html#adfef198bf3da7180630b45404eedd68a", null ],
    [ "getStackTrace", "a00489.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];