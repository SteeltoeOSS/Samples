var a00493 =
[
    [ "getMessage", "a00493.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00493.html#a825f8f00d4848e995a449ef10382585b", null ],
    [ "getStackTrace", "a00493.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];