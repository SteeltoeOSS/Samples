var a00449 =
[
    [ "fromData", "a00449.html#a666eb7a6a741d77cc540964099bc7ff4", null ],
    [ "getType", "a00449.html#ae1a7db6a55cd95e5c4bd779ca83b7043", null ],
    [ "objectSize", "a00449.html#aa1e74dde03eb0d3fb17752bfdcd347ef", null ],
    [ "toData", "a00449.html#a66cdb104852671d5d0ad41f189b59ec2", null ],
    [ "toString", "a00449.html#ac7a8d506b1a6f8313302b5efd0990378", null ]
];