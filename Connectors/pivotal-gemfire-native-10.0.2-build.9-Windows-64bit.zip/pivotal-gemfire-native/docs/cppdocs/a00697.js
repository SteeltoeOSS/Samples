var a00697 =
[
    [ "getMessage", "a00697.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00697.html#a4eb455bb6e469b8610509aaf9879f75f", null ],
    [ "getStackTrace", "a00697.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];