var a00593 =
[
    [ "getMessage", "a00593.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00593.html#ad34e3ac89363db701209a52157d7f391", null ],
    [ "getStackTrace", "a00593.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];