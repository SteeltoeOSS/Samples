var a00497 =
[
    [ "getMessage", "a00497.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00497.html#a5186a439415da383d2cbf8a75ec0e85a", null ],
    [ "getStackTrace", "a00497.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];