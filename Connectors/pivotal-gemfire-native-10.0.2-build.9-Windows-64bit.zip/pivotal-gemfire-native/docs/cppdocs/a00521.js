var a00521 =
[
    [ "getMessage", "a00521.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00521.html#a4bbb2aa02e652a484a526520d607de68", null ],
    [ "getStackTrace", "a00521.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];