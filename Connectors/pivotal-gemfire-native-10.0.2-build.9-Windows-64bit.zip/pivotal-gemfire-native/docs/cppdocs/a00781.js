var a00781 =
[
    [ "close", "a00781.html#a8796c68a02ca2cb6d40167a4ccf4556c", null ],
    [ "destroy", "a00781.html#ab52e1a2deab8c20db07a5007e3d91de3", null ],
    [ "init", "a00781.html#a7c823ff84c48c598581bc1903bc9c6af", null ],
    [ "read", "a00781.html#a1ddf20039371c73ededad0160b0c516b", null ],
    [ "readAll", "a00781.html#a031c8fa4eec38e3f7ee3cfbe78ecb930", null ],
    [ "write", "a00781.html#a8390100e20d88ad6527ff8391a037408", null ],
    [ "writeAll", "a00781.html#aef9468921fff75768ba6809224b1ae3b", null ],
    [ "m_regionPtr", "a00781.html#a57726d90c0ff1b61ce8cf1bd58a82e65", null ]
];