var a00709 =
[
    [ "getMessage", "a00709.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00709.html#a8644d8a44b7e8a79a3792d78ea222798", null ],
    [ "getStackTrace", "a00709.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];