var a00505 =
[
    [ "getMessage", "a00505.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00505.html#af1339acbd86129e7d4b19c161bc0ab65", null ],
    [ "getStackTrace", "a00505.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];