var a00841 =
[
    [ "ResultCollector", "a00841.html#a3f2a157b14b8c21f586c2325776e6e03", null ],
    [ "addResult", "a00841.html#adfb3fb793a4dd7fcec334a083b4f6967", null ],
    [ "clearResults", "a00841.html#a8454297e6d0407859a1d57a6f95a5d4a", null ],
    [ "endResults", "a00841.html#a599979d80e433a8e26fb25c29a43e0b3", null ],
    [ "getResult", "a00841.html#a9eb6f392dcc27a6053db46bb26508b15", null ]
];