var a00745 =
[
    [ "~PartitionResolver", "a00745.html#a8c4eac0ea8435f6e28ef2417e0b2cdd9", null ],
    [ "PartitionResolver", "a00745.html#af201d1ddf3ff2a89924a108e047657ec", null ],
    [ "getName", "a00745.html#a68793ed428ca0d18ed5aad5bb8e00bf3", null ],
    [ "getRoutingObject", "a00745.html#a6492385156922aca28af866905e5f554", null ]
];