var a00421 =
[
    [ "close", "a00421.html#a772a8afcb3fbfb9dc0f54e7dce22cf1f", null ],
    [ "execute", "a00421.html#ab8bb589c8d2656211b6c9185ac68ba82", null ],
    [ "executeWithInitialResults", "a00421.html#a8d6322798f05d74adf846b4f6ce0cbe0", null ],
    [ "getCqAttributes", "a00421.html#a6ca8a0f64f06ded6689d6863bab6b689", null ],
    [ "getCqAttributesMutator", "a00421.html#aa89e7469334f92246de0e79e5d9b6f20", null ],
    [ "getName", "a00421.html#ad69ad2cc9a8266320c80a49dde3eee8e", null ],
    [ "getQuery", "a00421.html#a1347d588c1167bc3fac7e17a2e4b18f5", null ],
    [ "getQueryString", "a00421.html#af8fcacf17371d5dc81a60fcd72e1db16", null ],
    [ "getState", "a00421.html#a624bb1628a93946cda0ba78ca050a9c4", null ],
    [ "getStatistics", "a00421.html#a06777e0ab5180083134a804a2b966d90", null ],
    [ "isClosed", "a00421.html#a03df6fa98290cfa8bf80937d187b90d6", null ],
    [ "isDurable", "a00421.html#a1275d81de8cb0c0bb21094d088ccc8a5", null ],
    [ "isRunning", "a00421.html#a62d53f5b8b9baa4f334e7d246c7613e6", null ],
    [ "isStopped", "a00421.html#a2de7b1d1912509cae1b48e4f4ecb60ab", null ],
    [ "stop", "a00421.html#aec3c3b4d31da5e430e80ca86c3e526f0", null ]
];