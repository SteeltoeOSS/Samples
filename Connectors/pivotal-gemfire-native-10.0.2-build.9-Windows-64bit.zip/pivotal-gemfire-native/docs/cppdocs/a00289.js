var a00289 =
[
    [ "close", "a00289.html#a709c65fc2cd45f67ce3d6603df9bc7f1", null ],
    [ "close", "a00289.html#a8676b128ff2e84212860694d48471c6d", null ],
    [ "createAuthenticatedView", "a00289.html#a44c8cce9718be5b6b24c27eabddee54e", null ],
    [ "createPdxInstanceFactory", "a00289.html#acdb522f5ea28fbff56544a004be7946c", null ],
    [ "createRegionFactory", "a00289.html#acdce453c9ede20bd5aa6d787a0032b62", null ],
    [ "getCacheTransactionManager", "a00289.html#a0a658b2846b5f8e5605a43bc8dbe158e", null ],
    [ "getName", "a00289.html#a60e53f6d51eee37ef5526db665a3ebab", null ],
    [ "getPdxIgnoreUnreadFields", "a00289.html#abc85e20b6a09462d7840372cda9717b7", null ],
    [ "getPdxReadSerialized", "a00289.html#a923d251279eed32952aa777ba80fc1f0", null ],
    [ "getQueryService", "a00289.html#a2e58689fed2e5a2a2c99085e8b3034db", null ],
    [ "getQueryService", "a00289.html#a4f6bf9b240f0dc25b6606164f535e626", null ],
    [ "getRegion", "a00289.html#af80a5d73de38233b22e409fe55c51a00", null ],
    [ "getTypeRegistry", "a00289.html#a066e1d6796dc85d3aed52739a86f9a6a", null ],
    [ "initializeDeclarativeCache", "a00289.html#af15c890de627c7aebb7800c4ad235cbe", null ],
    [ "isClosed", "a00289.html#a989d7fce829d1d12e7da49052445898d", null ],
    [ "readyForEvents", "a00289.html#ac2db841bef19d9a508f15245b6b65b08", null ],
    [ "rootRegions", "a00289.html#a7a2a54c73beae53d3d3fd9809432ee3b", null ]
];