var a00433 =
[
    [ "numDeletes", "a00433.html#a57f77354f49ddbef336663fcf0893cb8", null ],
    [ "numEvents", "a00433.html#ae46ab6d7264608ac130f979f1b6cd1ee", null ],
    [ "numInserts", "a00433.html#a5ca83f224a3aade7c6232fbc1fe26824", null ],
    [ "numUpdates", "a00433.html#aedfb1a9fd9a4f25f7e2d5baa5c500b70", null ]
];