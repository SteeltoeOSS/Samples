var a00613 =
[
    [ "getMessage", "a00613.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00613.html#a23a43368a56e8429032f8261148b14c4", null ],
    [ "getStackTrace", "a00613.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];