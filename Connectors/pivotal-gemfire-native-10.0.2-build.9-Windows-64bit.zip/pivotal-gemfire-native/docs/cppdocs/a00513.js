var a00513 =
[
    [ "getMessage", "a00513.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00513.html#a7a61509d2e7276582a1b1e8326f1e081", null ],
    [ "getStackTrace", "a00513.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];