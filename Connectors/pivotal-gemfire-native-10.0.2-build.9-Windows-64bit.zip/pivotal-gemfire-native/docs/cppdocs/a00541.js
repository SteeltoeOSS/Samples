var a00541 =
[
    [ "getMessage", "a00541.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00541.html#abbce9e3917cf089419d9b4c3703f9404", null ],
    [ "getStackTrace", "a00541.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];