var a00385 =
[
    [ "close", "a00385.html#a78128df22aca9cee08dc684fe98f5327", null ],
    [ "load", "a00385.html#aa79596f50779a0532a13638c2a85c90e", null ]
];