var a00537 =
[
    [ "getMessage", "a00537.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00537.html#a121ed4416281d30bb0f08d6460c0b9ec", null ],
    [ "getStackTrace", "a00537.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];