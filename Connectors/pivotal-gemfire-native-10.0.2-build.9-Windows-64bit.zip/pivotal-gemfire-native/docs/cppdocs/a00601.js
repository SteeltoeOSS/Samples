var a00601 =
[
    [ "getMessage", "a00601.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00601.html#a64cfa2368296220824171115ab8f5651", null ],
    [ "getStackTrace", "a00601.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];