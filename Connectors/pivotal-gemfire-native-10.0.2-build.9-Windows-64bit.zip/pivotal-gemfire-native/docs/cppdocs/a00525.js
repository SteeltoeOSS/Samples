var a00525 =
[
    [ "getMessage", "a00525.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00525.html#a451784ad6e73381e8d78042b1020a302", null ],
    [ "getStackTrace", "a00525.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];