var a00617 =
[
    [ "getMessage", "a00617.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00617.html#aab71bf0ace925514faad55b933f40a03", null ],
    [ "getStackTrace", "a00617.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];