var a00809 =
[
    [ "closeCqs", "a00809.html#ab03a9f051d462060c4299624975e03ca", null ],
    [ "executeCqs", "a00809.html#a4b676cdbdce07fca000789df6e5ea724", null ],
    [ "getAllDurableCqsFromServer", "a00809.html#a3d882aaad5517a88b7568d6d5708d7d5", null ],
    [ "getCq", "a00809.html#ad754c5568f06499f7ce52fa25373bef1", null ],
    [ "getCqs", "a00809.html#aa809b95267fe2346ca05da62ab10d3d4", null ],
    [ "getCqServiceStatistics", "a00809.html#a9750b7d30a2d73ddc53d8a23d72a0cc6", null ],
    [ "newCq", "a00809.html#ad2715272fc10d26223d2dee60f2d78d4", null ],
    [ "newCq", "a00809.html#acd2763e85abcd5035fc534af9f0b0d0a", null ],
    [ "newQuery", "a00809.html#ab4039c6723b533a165d1af714314c32e", null ],
    [ "stopCqs", "a00809.html#ab07dc8ad779710ab9713b06bf7aee1fa", null ]
];