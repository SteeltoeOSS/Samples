var a00661 =
[
    [ "getMessage", "a00661.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00661.html#a04b034ea90fabf136d57d92ade6d6f55", null ],
    [ "getStackTrace", "a00661.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];