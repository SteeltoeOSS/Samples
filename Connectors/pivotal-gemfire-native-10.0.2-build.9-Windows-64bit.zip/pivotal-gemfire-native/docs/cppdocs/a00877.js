var a00877 =
[
    [ "getMessage", "a00877.html#a3eb0ff21c99cb4d9e328574650940398", null ],
    [ "getName", "a00877.html#aaa68d19a79f05cbb05184b601d08d116", null ],
    [ "objectSize", "a00877.html#aa1e74dde03eb0d3fb17752bfdcd347ef", null ],
    [ "toString", "a00877.html#a928d2aa4a8a1f466f6f06ec7fa7d1f7d", null ]
];