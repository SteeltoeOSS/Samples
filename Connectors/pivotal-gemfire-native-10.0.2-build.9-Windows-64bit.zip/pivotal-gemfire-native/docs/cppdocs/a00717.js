var a00717 =
[
    [ "getMessage", "a00717.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00717.html#ada9693822c43dc91045ea8b273319efc", null ],
    [ "getStackTrace", "a00717.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];