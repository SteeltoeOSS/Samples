var a00681 =
[
    [ "getMessage", "a00681.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00681.html#a9779c2f4c8ab949e3af44e7940a3f156", null ],
    [ "getStackTrace", "a00681.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];