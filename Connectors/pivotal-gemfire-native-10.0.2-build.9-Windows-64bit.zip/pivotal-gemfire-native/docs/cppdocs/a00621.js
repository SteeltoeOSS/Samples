var a00621 =
[
    [ "getMessage", "a00621.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00621.html#a3486f73b6f1b681271d772c51acb41c5", null ],
    [ "getStackTrace", "a00621.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];