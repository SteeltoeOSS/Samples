var a00625 =
[
    [ "getMessage", "a00625.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00625.html#aa1461d8f31a08ed08f5b8d92136e775f", null ],
    [ "getStackTrace", "a00625.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];