var a00553 =
[
    [ "getMessage", "a00553.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00553.html#a715872e7334457cdaae705691236b439", null ],
    [ "getStackTrace", "a00553.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];