var a00829 =
[
    [ "RegionEvent", "a00829.html#a5c0c897a44b0e2ac7cc0423a44a4c5b6", null ],
    [ "RegionEvent", "a00829.html#a1bc795bd1e331869043e63b149863b8b", null ],
    [ "~RegionEvent", "a00829.html#aca4ae756385907979ba551bdbed4e722", null ],
    [ "getCallbackArgument", "a00829.html#aa7ec00c4d5e3b4ee981c232e7a039c0a", null ],
    [ "getRegion", "a00829.html#aa256dbff802f00ddac590484967459dc", null ],
    [ "remoteOrigin", "a00829.html#a3b6b844c728868bc046c618d945d274f", null ],
    [ "m_callbackArgument", "a00829.html#a5a7805bcc5b6140e0dbe4fc0ed338458", null ],
    [ "m_region", "a00829.html#aa838739267f38bfd0a03238397f2c01e", null ],
    [ "m_remoteOrigin", "a00829.html#a89634c5befdb4f9cff20c03ef9f25104", null ]
];