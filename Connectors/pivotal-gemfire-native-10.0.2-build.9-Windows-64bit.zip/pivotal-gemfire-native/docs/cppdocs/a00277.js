var a00277 =
[
    [ "AttributesMutator", "a00277.html#a757368afb9b227286dcffab5722db145", null ],
    [ "setCacheListener", "a00277.html#a6e3b9ff1d43662a39ad1dd2d6a42c717", null ],
    [ "setCacheListener", "a00277.html#a643fa1b12368d3e1f0195ad91805cb68", null ],
    [ "setCacheLoader", "a00277.html#a12dd1f9832306addcff86742d5e98402", null ],
    [ "setCacheLoader", "a00277.html#adc32f8c1acc074b655bb7be724886ec5", null ],
    [ "setCacheWriter", "a00277.html#a62c037d2190aaf97727a1e965ce8d441", null ],
    [ "setCacheWriter", "a00277.html#a6b136882df993cbe9b6a4b188f55d6dd", null ],
    [ "setEntryIdleTimeout", "a00277.html#a9211a39c69327dbc15ba1b75b57a1e1b", null ],
    [ "setEntryIdleTimeoutAction", "a00277.html#ab7ec0506ae2dec959664ce1939b98907", null ],
    [ "setEntryTimeToLive", "a00277.html#a63c92ad7301574ed03918958d995ba09", null ],
    [ "setEntryTimeToLiveAction", "a00277.html#a10a385f3489d1a539e64c2969ae85bfd", null ],
    [ "setLruEntriesLimit", "a00277.html#a83fdc55911b9f369196d18b6f4a9515a", null ],
    [ "setRegionIdleTimeout", "a00277.html#a1d14eaba31d5f8f1dcce48bed5a99a64", null ],
    [ "setRegionIdleTimeoutAction", "a00277.html#a6c6c9185146c913f81007c575943fbf9", null ],
    [ "setRegionTimeToLive", "a00277.html#a9334005f05819fc4e7c41b5c3474e70e", null ],
    [ "setRegionTimeToLiveAction", "a00277.html#a6582b9d301f10ca95036a76d6ed53428", null ]
];