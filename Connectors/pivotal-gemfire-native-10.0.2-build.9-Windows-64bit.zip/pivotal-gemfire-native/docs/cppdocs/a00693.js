var a00693 =
[
    [ "getMessage", "a00693.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00693.html#a1874b70ae0a9d32cde678911b68dbbf6", null ],
    [ "getStackTrace", "a00693.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];