var a00393 =
[
    [ "begin", "a00393.html#a0981149d55ba268e0599daa32cb373fa", null ],
    [ "commit", "a00393.html#abf655e511f2fae3bdc6746e2cfa941aa", null ],
    [ "exists", "a00393.html#a262cbb8bb675167abcb99289b8f27529", null ],
    [ "exists", "a00393.html#aa5fec7a72fd3778176bc110d3e05f86e", null ],
    [ "getTransactionId", "a00393.html#aaac9612c9c13933ca31f81ac8a6ca431", null ],
    [ "isSuspended", "a00393.html#a77a2e4d0bd8a240700f087ed4156cff0", null ],
    [ "resume", "a00393.html#aadf2e9d5586ff6d59a43876c3aef30ac", null ],
    [ "rollback", "a00393.html#af52d5c2e1b776ecabde5f3d60f474a49", null ],
    [ "suspend", "a00393.html#a89106519ecfbb7cf0aacf42c2580c446", null ],
    [ "tryResume", "a00393.html#ad5b2cdfb8f1cd389690cbd466a1f01c7", null ],
    [ "tryResume", "a00393.html#acbb0a029a4bea5d215b0c3ff588429b7", null ]
];