var a00673 =
[
    [ "getMessage", "a00673.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00673.html#aa4ccdc16fdf23bd90df467b7ec113ff8", null ],
    [ "getStackTrace", "a00673.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];