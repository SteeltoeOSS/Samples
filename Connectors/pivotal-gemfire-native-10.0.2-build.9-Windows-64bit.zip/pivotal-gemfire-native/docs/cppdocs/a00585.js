var a00585 =
[
    [ "getMessage", "a00585.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00585.html#a51c3ef9c134a4b915fe89efc6326f663", null ],
    [ "getStackTrace", "a00585.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];