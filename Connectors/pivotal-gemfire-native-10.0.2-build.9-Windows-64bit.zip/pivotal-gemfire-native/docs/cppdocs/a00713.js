var a00713 =
[
    [ "getMessage", "a00713.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00713.html#ad0d0ab12722dd310d115a76b413a7f8a", null ],
    [ "getStackTrace", "a00713.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];