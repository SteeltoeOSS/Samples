var a00529 =
[
    [ "getMessage", "a00529.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00529.html#a445cca4a1d75b674aac725ed666e1d93", null ],
    [ "getStackTrace", "a00529.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];