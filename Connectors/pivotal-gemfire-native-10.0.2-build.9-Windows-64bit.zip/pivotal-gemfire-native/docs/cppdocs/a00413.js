var a00413 =
[
    [ "getBaseOperation", "a00413.html#afb1f2ffeba76d70b8197c9d389ed137e", null ],
    [ "getCq", "a00413.html#a83804f7cc751c6a6535a70e4fd5bfda8", null ],
    [ "getDeltaValue", "a00413.html#acb738a3e119d98d5e674cc6de573370c", null ],
    [ "getKey", "a00413.html#add734d004ac1561d12f3222c70c1c058", null ],
    [ "getNewValue", "a00413.html#a23d98d6438e368f0a986c6494253fb11", null ],
    [ "getQueryOperation", "a00413.html#a0684ef99d984bf1cf57fdd5be35a959c", null ]
];