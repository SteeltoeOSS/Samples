var a00689 =
[
    [ "getMessage", "a00689.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00689.html#a98ddc78e5fdb2710005e49020f7e916d", null ],
    [ "getStackTrace", "a00689.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];