var a00501 =
[
    [ "getMessage", "a00501.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00501.html#a545e400bed20d30714e92a8244e6a5a1", null ],
    [ "getStackTrace", "a00501.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];