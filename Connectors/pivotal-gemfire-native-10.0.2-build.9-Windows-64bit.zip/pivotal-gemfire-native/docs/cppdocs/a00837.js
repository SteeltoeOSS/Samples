var a00837 =
[
    [ "close", "a00837.html#ad491b3447896e480666fdae6d9c96ab9", null ],
    [ "createPdxInstanceFactory", "a00837.html#a0dcd1860f71f30172e4303f5d8439c4c", null ],
    [ "getQueryService", "a00837.html#a750c5523f7f9b2aab4b91993466164c9", null ],
    [ "getRegion", "a00837.html#a50370f5b4d144c8742baceb0eaa4cfe3", null ],
    [ "isClosed", "a00837.html#a0a9bb57c509648270a50abc5afea1dae", null ],
    [ "rootRegions", "a00837.html#acd245c4e15d2025a78c7fa7e8652529a", null ]
];