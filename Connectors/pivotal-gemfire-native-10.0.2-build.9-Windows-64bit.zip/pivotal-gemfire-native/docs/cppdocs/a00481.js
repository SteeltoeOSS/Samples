var a00481 =
[
    [ "getMessage", "a00481.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00481.html#acb397b8776fdfcece098f5236c84926d", null ],
    [ "getStackTrace", "a00481.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];