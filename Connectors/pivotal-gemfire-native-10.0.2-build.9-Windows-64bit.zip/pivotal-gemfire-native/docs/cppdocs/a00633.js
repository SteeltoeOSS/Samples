var a00633 =
[
    [ "getMessage", "a00633.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00633.html#a2e470fca4b0ff6c5ecb4d7efab3be8ed", null ],
    [ "getStackTrace", "a00633.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];