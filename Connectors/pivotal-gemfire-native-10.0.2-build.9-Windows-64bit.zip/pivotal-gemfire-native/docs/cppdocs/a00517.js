var a00517 =
[
    [ "getMessage", "a00517.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00517.html#a2a094d3ce2a253779866fe52b42e4d76", null ],
    [ "getStackTrace", "a00517.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];