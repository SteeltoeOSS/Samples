var a00677 =
[
    [ "getMessage", "a00677.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00677.html#acdcef801cf030f6f22d673f80a85048e", null ],
    [ "getStackTrace", "a00677.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];