var a00665 =
[
    [ "getMessage", "a00665.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00665.html#a57acbfb81cf6fef4060261a121e4a54f", null ],
    [ "getStackTrace", "a00665.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];