var a00669 =
[
    [ "getMessage", "a00669.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00669.html#a76d9c54f4c2fb68a4aa6f3ab03c314fc", null ],
    [ "getStackTrace", "a00669.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];