var a00477 =
[
    [ "getMessage", "a00477.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00477.html#a0bc0ab493bb296ea89e3044816aa2ef6", null ],
    [ "getStackTrace", "a00477.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];