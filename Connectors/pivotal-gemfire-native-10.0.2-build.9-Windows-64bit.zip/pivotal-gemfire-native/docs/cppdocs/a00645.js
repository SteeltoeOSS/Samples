var a00645 =
[
    [ "getMessage", "a00645.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00645.html#a4dbae0a48336c1d139056052c5d7cb99", null ],
    [ "getStackTrace", "a00645.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];