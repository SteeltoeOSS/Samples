var a00733 =
[
    [ "getName", "a00733.html#a68793ed428ca0d18ed5aad5bb8e00bf3", null ],
    [ "getPartitionName", "a00733.html#a16b169d39ebfd1254b98e4c05945707c", null ],
    [ "getRoutingObject", "a00733.html#a6492385156922aca28af866905e5f554", null ]
];