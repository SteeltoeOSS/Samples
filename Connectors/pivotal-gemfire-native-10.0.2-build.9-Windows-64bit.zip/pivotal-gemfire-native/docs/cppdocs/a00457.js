var a00457 =
[
    [ "clone", "a00457.html#a1e7f453bd111f2d0dc24d97e47cd7810", null ],
    [ "fromDelta", "a00457.html#a722438e8f9011c8943b400d726d784f3", null ],
    [ "hasDelta", "a00457.html#aee49a30db31321cde7673481ff2f3fe5", null ],
    [ "toDelta", "a00457.html#afa848968dd5ee554afaa0eb33537a7fb", null ]
];