var a00629 =
[
    [ "getMessage", "a00629.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00629.html#a6a51a717f50f17922e76e8ad3d224eba", null ],
    [ "getStackTrace", "a00629.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];