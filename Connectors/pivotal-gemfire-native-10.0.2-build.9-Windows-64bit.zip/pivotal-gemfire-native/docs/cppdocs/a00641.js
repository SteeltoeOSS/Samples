var a00641 =
[
    [ "getMessage", "a00641.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00641.html#abae42cf264d9a0b8db4eeea22fbfb5e1", null ],
    [ "getStackTrace", "a00641.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];