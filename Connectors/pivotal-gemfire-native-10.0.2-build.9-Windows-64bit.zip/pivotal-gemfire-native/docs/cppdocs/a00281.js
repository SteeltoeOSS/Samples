var a00281 =
[
    [ "~AuthenticatedView", "a00281.html#a4515dc813d9d4e80bb0fa5cf183678aa", null ],
    [ "AuthenticatedView", "a00281.html#a26b1a82f8772ff63f81967a1616da618", null ],
    [ "close", "a00281.html#adb3ba6b5cacf6acbc6ba2d4bbcbdfcb3", null ],
    [ "createPdxInstanceFactory", "a00281.html#a5474bd404826e32971288a2f098272d2", null ],
    [ "getQueryService", "a00281.html#afdde5da469a3313a2ed2dc8a6f7f9e71", null ],
    [ "getRegion", "a00281.html#a7620efbbc3004681ec6622a5fa3c926c", null ],
    [ "isClosed", "a00281.html#ae11f988865fe1074f84b9932f0e7c78d", null ],
    [ "rootRegions", "a00281.html#ae96bdb4d42e7c2072ed667236cd0b35b", null ]
];