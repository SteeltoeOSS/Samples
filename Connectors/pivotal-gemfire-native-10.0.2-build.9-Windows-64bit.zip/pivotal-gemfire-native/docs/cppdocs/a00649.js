var a00649 =
[
    [ "getMessage", "a00649.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00649.html#a02aaed56e5599563f6e3b1fcd3de5e6f", null ],
    [ "getStackTrace", "a00649.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];