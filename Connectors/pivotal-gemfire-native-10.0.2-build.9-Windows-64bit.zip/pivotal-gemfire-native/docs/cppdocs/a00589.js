var a00589 =
[
    [ "getMessage", "a00589.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00589.html#a3a9d8a4d8d5876c38f061bfbc63b7aa8", null ],
    [ "getStackTrace", "a00589.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];