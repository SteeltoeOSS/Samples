var a00373 =
[
    [ "getEndpoints", "a00373.html#a64dcd14ec3c3badd95ccf18d447acf77", null ],
    [ "getRedundancyLevel", "a00373.html#a7de1a7e301b0f8564599860fa7226757", null ]
];