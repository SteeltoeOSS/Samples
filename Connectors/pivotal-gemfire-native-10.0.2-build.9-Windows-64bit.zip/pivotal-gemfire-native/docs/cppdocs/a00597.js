var a00597 =
[
    [ "getMessage", "a00597.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00597.html#a7b980f34bfed2616bed646664aae665f", null ],
    [ "getStackTrace", "a00597.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];