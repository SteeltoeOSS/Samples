var a00825 =
[
    [ "RegionEntry", "a00825.html#ada1ace62a2496910d89e1de5d8e85607", null ],
    [ "getKey", "a00825.html#ad8293cabdfc3e7c3da6444af6c244ca5", null ],
    [ "getRegion", "a00825.html#ad93c5181fa19ceeae6832908b36cf63a", null ],
    [ "getStatistics", "a00825.html#a999f71322bd2810115655a4416a67821", null ],
    [ "getValue", "a00825.html#a46483a043f51beabf59d0d2163c5273b", null ],
    [ "isDestroyed", "a00825.html#ab3c5cdcb2849d943527534b56a4fc7d9", null ]
];