var a00549 =
[
    [ "getMessage", "a00549.html#a4a13dbe4fe4936a0f92451738bab6f74", null ],
    [ "getName", "a00549.html#ad91d974187735b7b965944c16d5cab40", null ],
    [ "getStackTrace", "a00549.html#ae92dba8992cbda0cd2aaa1d6fa05b54f", null ]
];