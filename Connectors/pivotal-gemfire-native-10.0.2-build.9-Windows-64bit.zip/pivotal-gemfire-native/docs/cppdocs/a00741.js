var a00741 =
[
    [ "close", "a00741.html#ad491b3447896e480666fdae6d9c96ab9", null ],
    [ "createPdxInstanceFactory", "a00741.html#a0dcd1860f71f30172e4303f5d8439c4c", null ],
    [ "getName", "a00741.html#aa66e073929f5df451356253c9771ddd9", null ],
    [ "getPdxIgnoreUnreadFields", "a00741.html#a13ae5a505b283e1f73b1be1a8677f722", null ],
    [ "getPdxReadSerialized", "a00741.html#ae086ef606de28739132eaa0733fd310a", null ],
    [ "getQueryService", "a00741.html#a750c5523f7f9b2aab4b91993466164c9", null ],
    [ "getRegion", "a00741.html#a50370f5b4d144c8742baceb0eaa4cfe3", null ],
    [ "initializeDeclarativeCache", "a00741.html#ad1dd178d54fe47897d3ea2f0694b4fbd", null ],
    [ "isClosed", "a00741.html#a0a9bb57c509648270a50abc5afea1dae", null ],
    [ "rootRegions", "a00741.html#acd245c4e15d2025a78c7fa7e8652529a", null ]
];